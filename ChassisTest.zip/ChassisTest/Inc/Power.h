#ifndef power_h
#define power_h


void PowerInit(void );



#endif
