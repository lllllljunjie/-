#ifndef __contor_motor_h
#define __contor_motor_h
#ifdef __cplusplus
 extern "C" {
#endif
#include"main.h"

typedef struct 
{
	int16_t Motor1Out;
	int16_t Motor2Out;
	int16_t Motor3Out;
	int16_t Motor4Out;
	
	int16_t Motor1FDB;
	int16_t Motor2FDB;
	int16_t Motor3FDB;
	int16_t Motor4FDB;
}MotorData;

void CAN1_Config(void);
uint8_t Can1_TxMessage(uint8_t ide,uint32_t id,uint8_t len,uint8_t *data);
void 	SendMotoeMassage(MotorData *TxMessage);
extern MotorData Speed;
extern MotorData Position;
#endif
